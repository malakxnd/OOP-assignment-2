// Malak Moustafa Abdel Maboud 20237015
// Jumanah Muhammad Ali Rushdi 20237003
#include <iostream>
using namespace std;
#include <fstream>
#include "Doctor.cpp"
#include "Specialist.cpp"
#include "SurgerySchedules.cpp"
#include "Surgeon.cpp"
int main()
{
    // Declaring variables:
    int docNo;
    string name, ID;
    char choice;
    double duration, rate;
    int num; // Number of surgeries scheduled
    SurgerySchedules *surgeries;
    // Asking the user to enter the number of doctors
    cout << "Enter the number of doctors: " << endl;
    cin >> docNo;
    //A pointer of pointers to store all the entered doctors
    Doctor** doctors = new Doctor*[docNo];
    // Looping through the number of doctors
    for (int i = 0; i < docNo; i++)
    { // Asking the user to enter the type of the doctor (Specialist or Surgeon)
        cout << "Enter the type of the doctor: 'Specialist' or 'Surgeon': " << endl;
        cout<<"Click 1 for Specialist and 2 for Surgeon"<<endl;
        cin >> choice;
        // Enter name, speciality, ID, duration, and rate of the doctor
        if (choice == '1')
        {
            string speciality;
            cout << "Doctor name: " << endl;
            cin.ignore(); // to clear the buffer
            getline(cin, name);
            cout << "Doctor speciality: " << endl;
            cin>>speciality;
            cout << "Doctor ID: " << endl;
            cin >> ID;
            cout << "Enter duration: " << endl;
            cin >> duration;
            cout << "Enter rate: " << endl;
            cin >> rate;
            // Store the doctor info in the 2d dynamic array
            // Create a Specialist object
            doctors[i] = new Specialist(name,speciality, ID, duration, rate);
            // Print the doctor's name and the total fee
            cout << ((Specialist*)doctors[i])->PrettyPrint() << endl;
        }
        // Enter the name, number of surgeries scheduled, the name of the patient, the date of the surgery, ID, duration, and rate of the doctor
        else if (choice == '2')
        {
            cout << "Surgeon name: " << endl;
            cin.ignore();// to clear the buffer
            getline(cin, name);
            cout << "Number of surgeries scheduled: " << endl;
            cin >> num;
            surgeries=new SurgerySchedules[num]; // Array of SurgerySchedules objects
            // Looping through the number of surgeries scheduled
            for (int i = 0; i < num; i++)
            {
                string patientName, date;
                cout << "Patient name: " << endl;
                cin.ignore();
                getline(cin, patientName);
                cout << "Enter the date of the surgery: " << endl;
                cin >> date;
                surgeries[i] = SurgerySchedules(patientName, date); // Creates a SurgerySchedules object
            }
            cout << "Surgeon ID: " << endl;
            cin >> ID;
            cout << "Enter duration: " << endl;
            cin >> duration;
            cout << "Enter rate: " << endl;
            cin >> rate;
            // Store the doctor info in the 2d dynamic array
            // Create a Surgeon object
            doctors[i] = new Surgeon(name, num, surgeries, ID, duration, rate);
            cout<<((Surgeon*)doctors[i])->PrettyPrint()<<endl; // Prints the doctor's name and the total fee
            // Prints the list of surgeries
            ((Surgeon*)doctors[i])->printSurgeries();
        }
    }
    //To create the "doctors.txt" file and write data to it
    ofstream OutFile("doctors.txt");
    for (int i = 0; i < docNo; i++) {
        // Print the returned string for the PrettyPrint()
        string info = doctors[i]->PrettyPrint();
        cout<<info<<endl;
        // Write all info's to the doctor.txt file
        OutFile << info << endl;
        // To include surgeries' schedule in the doctor.txt
        if (dynamic_cast<Surgeon*>(doctors[i])) {
            OutFile << "Surgeries scheduled:\n";
            for (int j = 0; j < num; j++) {
                OutFile<<"Surgery for: "<<surgeries[j].getName()<<" on "<<surgeries[j].getDate()<<endl;
            }

        }
    }
    // make sure to close the file once we are done
    OutFile.close();
    // delete the dynamic arrays
    for (int i = 0; i < docNo; ++i) {
        delete doctors[i];
    }
    delete[] doctors;
    delete[] surgeries;
    return 0;
}
