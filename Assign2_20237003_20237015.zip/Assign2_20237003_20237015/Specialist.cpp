// Malak Moustafa Abdel Maboud 20237015
// Jumanah Muhammad Ali Rushdi 20237003

#include "Specialist.h"
#include "Doctor.h"
#include <iostream>
using namespace std;

// default constructor
Specialist::Specialist() : Doctor()
{
  speciality = "";
}

// parameterized constructor
Specialist::Specialist(string Name, string Special, string ID, double DURATION, double RATE) : Doctor(Name, ID, DURATION, RATE)
{
  speciality = Special;
}

// to calculate the total fee but it's quarter an hour
double Specialist::calculateTotalFee()
{
  return (duration / 15) * rate;
}

// to override the PrettyPrint()
string Specialist::PrettyPrint()
{
  return "Dr. " + name + " is a Specialist with " + speciality + " whose total fee is " + to_string(calculateTotalFee());
}
