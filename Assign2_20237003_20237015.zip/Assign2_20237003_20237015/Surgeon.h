// Malak Moustafa Abdel Maboud 20237015
// Jumanah Muhammad Ali Rushdi 20237003
#include <iostream>
#include "SurgerySchedules.h"
#include "Doctor.h"
using namespace std;
#ifndef SURGEON_H
#define SURGEON_H
class Surgeon : public Doctor
{
private:
    int numSurgeriesScheduled;
    SurgerySchedules *surgerySchedules;

public:
    Surgeon();
    Surgeon(string, int, SurgerySchedules *, string, double, double);
    Surgeon(const Surgeon &);
    ~Surgeon();
    double calculateTotalFee();
    string PrettyPrint();
    void printSurgeries();
};
#endif // SURGEON_H
