// Malak Moustafa Abdel Maboud 20237015
// Jumanah Muhammad Ali Rushdi 20237003

#include <iostream>
using namespace std;

#include "Doctor.h"

// default constructor
Doctor::Doctor() {
    id="";
    name="";
    duration=0.0;
    rate=0.0;
}
// parameterized constructor
Doctor::Doctor(string NAME, string ID, double DURATION, double RATE) {
    id=ID;
    name=NAME;
    duration=DURATION;
    rate=RATE;
}
// to calculate the total fee
double Doctor::calculateTotalFee() {
    return duration*rate;
}
// to return the info of the doctor
string Doctor::PrettyPrint() {
    return "Doctor ID is " + id + ", and name is Dr. " + name;
}
