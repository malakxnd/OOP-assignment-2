// Malak Moustafa Abdel Maboud 20237015
// Jumanah Muhammad Ali Rushdi 20237003
#include <iostream>
using namespace std;
#include "Surgeon.h"
#include "SurgerySchedules.h"
#include "Doctor.h"
Surgeon::Surgeon() : Doctor()
{
    numSurgeriesScheduled = 0;
    surgerySchedules = nullptr;
} // Default constructor

Surgeon::Surgeon(string Name, int Num, SurgerySchedules *schedules, string ID, double DURATION, double RATE) : Doctor(Name, ID, DURATION, RATE)
{

    numSurgeriesScheduled = Num;
    surgerySchedules = new SurgerySchedules[numSurgeriesScheduled];
    for (int i = 0; i < numSurgeriesScheduled; i++)
    {
        surgerySchedules[i] = schedules[i];
    }
    // parameterized constructor
}

Surgeon::Surgeon(const Surgeon &obj)
{
    numSurgeriesScheduled = obj.numSurgeriesScheduled;              // Ensures the new object has the same array size as the original object.
    surgerySchedules = new SurgerySchedules[numSurgeriesScheduled]; // Dynamically allocates memory for the array in the new object.
    for (int i = 0; i < numSurgeriesScheduled; i++)
    {
        surgerySchedules[i] = obj.surgerySchedules[i];
    }
    // Copies each surgery schedule from the "obj" to the new object
} // Copy constructor

Surgeon::~Surgeon()
{
    delete[] surgerySchedules;
}

double Surgeon::calculateTotalFee()
{
    return (duration / 60) * rate;
} // Calculates total fees based on duration in minutes (Which is converted to hours) and rate per hour

string Surgeon::PrettyPrint()
{
    return "Dr." + name + " is a surgeon whose total fee is " + to_string(calculateTotalFee());
} // Displays the doctor's name and the total fee

void Surgeon::printSurgeries()
{
    for (int i = 0; i < numSurgeriesScheduled; i++)
    {
        cout << "Surgery for: " << surgerySchedules[i].getName() << " on " << surgerySchedules[i].getDate() << endl;
    }
}

