// Malak Moustafa Abdel Maboud 20237015
// Jumanah Muhammad Ali Rushdi 20237003

#include <iostream>
using namespace std;

#ifndef DOCTOR_H
#define DOCTOR_H

class Doctor
{
protected:
    string id, name;
    double duration, rate;

public:
    Doctor();
    Doctor(string, string, double, double);
    virtual double calculateTotalFee();
    virtual string PrettyPrint();
};

#endif // DOCTOR_H
