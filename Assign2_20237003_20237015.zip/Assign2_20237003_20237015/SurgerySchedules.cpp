// Malak Moustafa Abdel Maboud 20237015
// Jumanah Muhammad Ali Rushdi 20237003
#include <iostream>
using namespace std;
#include "SurgerySchedules.h"

SurgerySchedules::SurgerySchedules()
{
    patientName = "";
    Date = "";
} // Default constructor
SurgerySchedules::SurgerySchedules(string pn, string dt)
{
    patientName = pn;
    Date = dt;
} // Parameterized constructor
void SurgerySchedules::setName(string pn)
{
    patientName = pn;
}
void SurgerySchedules::setDate(string dt)
{
    Date = dt;
} // Setters
string SurgerySchedules::getName() const
{
    return patientName;
}
string SurgerySchedules::getDate() const
{
    return Date;
} // Getters