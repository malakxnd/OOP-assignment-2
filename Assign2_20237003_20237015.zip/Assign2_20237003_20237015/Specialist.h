// Malak Moustafa Abdel Maboud 20237015
// Jumanah Muhammad Ali Rushdi 20237003
#ifndef SPECIALIST_H
#define SPECIALIST_H
#include <iostream>
#include "Doctor.h"
using namespace std;

class Specialist : public Doctor
{
private:
  string speciality;

public:
  Specialist();
  Specialist(string, string, string, double, double);
  double calculateTotalFee();
  string PrettyPrint();
};

#endif // SPECIALIST_H
