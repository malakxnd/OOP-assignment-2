// Malak Moustafa Abdel Maboud 20237015
// Jumanah Muhammad Ali Rushdi 20237003
#include <iostream>
using namespace std;
#ifndef SURGERYSCHEDULES_H
#define SURGERYSCHEDULES_H

class SurgerySchedules
{
private:
    string patientName, Date;

public:
    SurgerySchedules();
    SurgerySchedules(string, string);
    void setName(string patientName);
    string getName() const;
    void setDate(string Date);
    string getDate() const;
};

#endif // SCHEDULE_H